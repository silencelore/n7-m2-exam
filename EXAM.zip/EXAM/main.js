let students = [
  { name: "Ali",
    grades: [90, 85, 95]},
  { name: "Vali",
    grades: [70, 80, 75]},
  { name: "Gul",
    grades: [95, 92, 98]}
];

let averages = students.map(student => {
  let avg = student.grades.reduce((sum, grade) => sum + grade, 0) / student.grades.length;
  return { name: student.name, averageGrade: avg };
});

let topStudents = averages.filter(s => s.averageGrade > 90);

averages.sort((a, b) => b.averageGrade - a.averageGrade);

function addStudent(name, grades) {
  students.push({ name, grades });

  let avg = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;
  averages.push(
    { name,
      averageGrade: avg });

  if (avg > 90) {
    topStudents.push(
      { 
        name,
        averageGrade: avg 
      });
  }

  averages.sort((a, b) => b.averageGrade - a.averageGrade);
}

addStudent("Zilola", [100, 95, 90]);

console.log("O'rtacha ball :", averages);
console.log("O'rtacha 90 dan tepa:", topStudents);

// 2

let products = [
    { id:1,
      name:"Geforce RTX5090",
      price:9000,
      stock:5 },
    { id:2,
      name:"Geforce RXT5080",
      price:1800,
      stock:0 },
    { id:3,
      name:"Geforce RTX5070",
      price:299,
      stock:3 }
  ];
  
  let available = products.filter(value => value.stock > 0);
  
  let values = available.map(value => ({ name:value.name, totalValue:value.price * value.stock }));
  
  let totalInventory = available.reduce((sum,value)=>sum + value.price*value.stock,0);
  
  available.sort((a,b)=>b.price - a.price);
  
  console.log(available);
  console.log(values);
  console.log("Total value =>", totalInventory);
  
// 3

let movies = [
    { title:"Avatar", totalSeats:100, reservedSeats:80 },
    { title:"Titanic", totalSeats:50, reservedSeats:50 },
    { title:"Matrix", totalSeats:70, reservedSeats:40 }
  ];
  
  movies.forEach(m => m.availableSeats = m.totalSeats - m.reservedSeats);
  
  let availableMovies = movies.filter(m => m.availableSeats > 0);
  
  availableMovies.sort((a,b)=>b.availableSeats - a.availableSeats);
  
  console.log(availableMovies);
  
// 4

let text = "Salom dunyo, bu ChatGPT misolidir!";
let words = text.split(" ");

let wordLength = words.map(value => ({ word:value, length:value.length }));

let long = wordLength.reduce((a,b)=> a.length > b.length ? a : b);

console.log(wordLength);
console.log("Uzun:", long);

// // 5

// let text2 = "level madam hello kayak world";
// let words2 = text2.split(" ");

// let palindromes = words2.filter(w => w === w.split("").reverse().join(""));
// console.log(palindromes);
// console.log("Palindromlar soni:", palindromes.length);

// // 6

// let text3 = "Salom dunyo, bu ChatGPT bilan ishlaymiz!";
// let letters = text3.toLowerCase().replace(/[^a-zа-яё]/g,"").split("");

// let freq = {};
// letters.forEach(l => freq[l] = (freq[l]||0)+1);

// let maxLetter = Object.entries(freq).reduce((a,b)=> a[1]>b[1]?a:b);

// console.log(freq);
// console.log("Eng ko‘p harf:", maxLetter);

// // 7

// let secretText = "Salom dunyo, ChatGPT bilan ishlaymiz!";
// let chars = secretText.split("");

// let codes = chars.map(c => c.charCodeAt(0));

// let oddCodes = codes.filter((c,i)=> i%2===1);

// let secretMessage = oddCodes.reverse();

// console.log(secretMessage);