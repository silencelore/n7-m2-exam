
// boshidagi uchta masala o'tkan darsliklardan olinganakan man o'tkan safar kasal bo'lib kelolmaganidim videoni ham yuklashmagan ekan erpda muammo bo'lgani uchun.

let students = [
  { name: "Ali",
    grades: [90, 85, 95]},
  { name: "Vali",
    grades: [70, 80, 75]},
  { name: "Gul",
    grades: [95, 92, 98]}
];

let averages = students.map(student => {
  let avg = student.grades.reduce((sum, grade) => sum + grade, 0) / student.grades.length;
  return { name: student.name, averageGrade: avg };
});

let topStudents = averages.filter(s => s.averageGrade > 90);

averages.sort((a, b) => b.averageGrade - a.averageGrade);

function addStudent(name, grades) {
  students.push({ name, grades });

  let avg = grades.reduce((sum, grade) => sum + grade, 0) / grades.length;
  averages.push(
    { name,
      averageGrade: avg });

  if (avg > 90) {
    topStudents.push(
      { 
        name,
        averageGrade: avg 
      });
  }

  averages.sort((a, b) => b.averageGrade - a.averageGrade);
}

addStudent("Zilola", [100, 95, 90]);

console.log("O'rtacha ball :", averages);
console.log("O'rtacha 90 dan tepa:", topStudents);

// 2

let products = [
    { id:1,
      name:"Geforce RTX5090",
      price:9000,
      stock:5 },
    { id:2,
      name:"Geforce RXT5080",
      price:1800,
      stock:0 },
    { id:3,
      name:"Geforce RTX5070",
      price:299,
      stock:3 }
  ];
  
  let available = products.filter(value => value.stock > 0);
  
  let values = available.map(value => ({ name:value.name, totalValue:value.price * value.stock }));
  
  let totalInventory = available.reduce((sum,value)=>sum + value.price*value.stock,0);
  
  available.sort((a,b)=>b.price - a.price);
  
  console.log(available);
  console.log(values);
  console.log("Total value =>", totalInventory);
  
// 3

let movies = [
    { title:"Avatar", totalSeats:100, reservedSeats:80 },
    { title:"Titanic", totalSeats:50, reservedSeats:50 },
    { title:"Matrix", totalSeats:70, reservedSeats:40 }
  ];
  
  movies.forEach(m => m.availableSeats = m.totalSeats - m.reservedSeats);
  
  let availableMovies = movies.filter(m => m.availableSeats > 0);
  
  availableMovies.sort((a,b)=>b.availableSeats - a.availableSeats);
  
  console.log(availableMovies);
  
// 4

let text = "Salom dunyo, bu ChatGPT misolidir!";
let words = text.split(" ");

let wordLength = words.map(value => ({ word:value, length:value.length }));

let long = wordLength.reduce((a,b)=> a.length > b.length ? a : b);

console.log(wordLength);
console.log("Uzun:", long);

// 5

let text2 = "level madam hello kayak world";
let words2 = text2.split(" ");

let palindromes = words2.filter(value => value === value.split("").reverse().join(""));
console.log(palindromes);
console.log("Palindromlar soni:", palindromes.length);

// 6

let text6 = prompt("Matn kiriting").toLowerCase();
let count = {};
let maxChar = "";
let maxCount = 0;

for (let i = 0; i < text6.length; i++) {
  let char = text6[i];

  if (char === " ") continue; 

  if (count[char]) {
    count[char]++;
  } else {
    count[char] = 1;
  }

  if (count[char] > maxCount) {
    maxCount = count[char];
    maxChar = char;
  }
}

console.log(count);
console.log("Eng ko‘p uchragan harf:", maxChar, maxCount, "marta");


// 7

let text7 = prompt("Matn kiriting").toLowerCase();
let count7 = {};
let maxChar7 = "";
let maxCount7 = 0;

for (let i = 0; i < text7.length; i++) {
  let char = text7[i];

  if (char === " ") continue; 

  if (count7[char]) {
    count7[char]++;
  } else {
    count7[char] = 1;
  }

  if (count7[char] > maxCount7) {
    maxCount7 = count7[char];
    maxChar7 = char;
  }
}

console.log(count7);
console.log("Eng ko‘p uchragan harf:", maxChar7, maxCount7, "marta");
